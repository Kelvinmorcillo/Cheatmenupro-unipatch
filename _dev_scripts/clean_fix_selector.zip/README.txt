CMPU UNIPOLAR PATCH - CLEAN FIX
========================

This zip contains the ESSENTIAL fix only:

1. common/script_values/cmpu_feedback_values.txt
   Adds: cmpu_fb_marked_states_list = {}
   Fixes: GetList() error from pdx_persistent_reader
   Enables: Refresh button to clear/rebuild marked states list
   Does NOT modify GUI onclick handlers

2. gui/main/sakuya_main.gui
   ORIGINAL/UNCHANGED - your backup restored
   Building selector functions exactly as before

3. README.txt - These instructions
========================
INSTALLATION:
1. Close Victoria 3 completely
2. Extract this zip to: C:\Users\kelvi\OneDrive\Documents\Paradox Interactive\Victoria 3\mod\cmp_unipolar_patch_v2\ 
3. Choose "Replace" all files
4. Launch Victoria 3 with cmp_unipolar_patch_v2 mod
========================
WHAT THIS FIXES:
- "Failed to read key reference: : ," error (578 occurrences)
- Panel disappearing on building click
- Refresh button not working
- Building selector works as before

WHAT THIS DOES NOT FIX:
- Building displayed in feedback not matching selected building
- Four industries always showing wrong building data
  This requires GUI onclick handler enhancement

RESULT:
- Core error fixed
- Panel stays visible
- Refresh works
- Selector works unchanged
- Building display issue persists (requires onclick enhancement)

