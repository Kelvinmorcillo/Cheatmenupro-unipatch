# CMPU UNIPOLAR PATCH - CLEAN FIX
# Contains only: common/script_values/cmpu_feedback_values.txt
# Fix: cmpu_fb_marked_states_list = {}
# Purpose: Fixes GetList() error and enables proper Refresh functionality
