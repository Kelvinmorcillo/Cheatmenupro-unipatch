# CMPU UNIPOLAR PATCH - FINAL FIX
#
# 1. Script values fix
# 2. GUI format fix
# 3. Building selector should work
# 4. Refresh should work
